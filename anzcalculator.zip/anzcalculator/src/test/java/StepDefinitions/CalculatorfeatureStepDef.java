package StepDefinitions;

import java.util.List;
import java.util.Map;
import io.cucumber.core.gherkin.Scenario;
import io.cucumber.datatable.DataTable;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import Pageobjectrepo.ANZCalcPageMethods;
import Pageobjectrepo.AnzCalcPageObject;
import TestBase.testbase;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.core.gherkin.Scenario;
 

public class CalculatorfeatureStepDef extends testbase{
	
		
	private static final By By = null;	
	WebDriver driver=testbase.selectBrowser("chrome");	
	ANZCalcPageMethods classobj= new ANZCalcPageMethods(driver);
	
	
	@Before	
	public void before(io.cucumber.java.Scenario scenario) {
		
		System.out.println(" Started  scenario::" + scenario.getName());
	}
		
		
	@After
	public void after(io.cucumber.java.Scenario scenario) {
		System.out.println(" Completed  scenario::" + scenario.getName());
		driver.quit();}
	
	
	
	@Given("^user wants to open the (.*)")
public void user_wants_to_open_the_URL(String string)
	{
		classobj.navigateURL(string);	
		
	}
		
	


    @When("user click on calculate estimate amount")
public void user_click_on_calculate_estimate_amount() {
	
    	classobj.Clickbutton(classobj.calculateBorowingAmt);
		}

@Then("user should able to see correct afforadability amount")
public void user_should_able_to_see_afforadability_amount() {
    
	classobj.retrieveandcompare(classobj.incomefieldpath,classobj.otherincome,classobj.livingexpense,classobj.loanrepayment,classobj.otherloanreapayment,classobj.otherCommitment,classobj.creditCardLimit,classobj.dependents,classobj.applicationtype,classobj.estimateamount);

    
}



@Then("user click on sartover button")
public void user_click_on_sartover_button() {
	classobj.Clickbutton(classobj.startOver);
 
}

@Then("Calculator page button is reset")
public void calculator_page_button_is_reset() {
	classobj.formreset(classobj.incomefieldpath,classobj.otherincome,classobj.livingexpense,classobj.loanrepayment,classobj.otherloanreapayment,classobj.otherCommitment,classobj.creditCardLimit,classobj.dependents,classobj.applicationtype,classobj.calculateBorowingAmt);

    
}

@Then("verify error message text")
public void verify_error_message_text() {
	
	
	WebElement field=driver.findElement(classobj.errorMessage);
	
	String Actualerrormessagetext=field.getText();
	
	System.out.println(Actualerrormessagetext);
	String Expectederrormessagetext="Based on the details you've entered, we're unable to give you an estimate of your borrowing power with this calculator. For questions, call us on 1800 100 641.";
	if(Expectederrormessagetext==Actualerrormessagetext) {
		System.out.println("correct error message displayed");
	}else {
		System.out.println("incorrect error message displayed");
		System.out.println("correct message should be" +Expectederrormessagetext);
		
	}}
	/*try {
		Assert.assertEquals(Expectederrormessagetext,Actualerrormessagetext);
		System.out.println("correct error message displayed");
	}
	
	catch (Exception e) {
	    String expectedMessage = "this is the message I expect to get";
	    Assert.assertEquals( "Exception message must be correct", expectedMessage, e.getMessage() );
	}*/
  


@Then("user enter personal income and expense detail")
public void enter_personal_detail(io.cucumber.datatable.DataTable caldata) {
	for (Map<Object, Object> data : caldata.asMaps(String.class, String.class)) {
	
		String fieldname=(String) data.get("fieldnamepath");
		String valuetobeentered=(String) data.get("value");
		classobj.calculatorpage(fieldname, valuetobeentered);
	     System.out.println(fieldname +" value entered is " + valuetobeentered);
	     }

}


}






