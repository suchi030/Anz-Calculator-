package Pageobjectrepo;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ANZCalcPageMethods {
	
		
	

	private static final By By = null;
	
	private static WebDriver driver;
	
	public ANZCalcPageMethods(WebDriver driver){
		this.driver = driver;
		
		
	}
	
	AnzCalcPageObject objectclass= new AnzCalcPageObject(driver);	
	public By incomefieldpath = objectclass.incomebeforetax_textbox_fieldpath;
	public By applicationtype = objectclass.applicationtypebutton;
	public By dependents = objectclass.numofdependents_Dropdown_fieldpath;
	public By propertyType = objectclass.propertytobuy_Button_fieldpath;
	public By otherincome = objectclass.otherincome_textbox_fieldpath;
	public By livingexpense = objectclass.livingexpense_textbox_fieldpath;
	public By loanrepayment = objectclass.Currenthomeloanrepayment_textbox_fieldpath;
	public By otherloanreapayment = objectclass.otherloansrepayment_textbox_fieldpath;
	public By otherCommitment = objectclass.othercommitments_textbox_fieldpath;
	public By creditCardLimit = objectclass.totalCreditcardlimits_textbox_fieldpath;
	public By calculateBorowingAmt = objectclass.howmuchcouldborrow_button_fieldpath;
	public By estimateamount = objectclass.estimateAmount_textbox_fieldpath;
	public By errorMessage = objectclass.errortext_textbox_fieldpath;
	public By startOver = objectclass.startover_button_fieldpath;
	
	
	public static void setvalue(By string2, String string) {
		
			WebElement field=driver.findElement(string2);
			
			field.sendKeys(string);
			
		}
	
	public String getvalue(By string2, String string) {
		
		WebElement field=driver.findElement(string2);
		verifyelement_visible_and_enable(field);
		string=field.getAttribute("value");
		
		if(string.isEmpty())
		{
		   System.out.println("Input field is empty");
		
		   }
		   else {
			    System.out.println(string2 + "has value" + string);
		   }
		return string;
		}
	
public void selectvalue(By string1, String string2, String string3) {
		
		WebElement field=driver.findElement(string1);
	
		
			   if(string2=="selectByVisibleText") 
			   
			   {
				   Select newselect=new Select(field);
			   			    newselect.selectByVisibleText(string3);
			   System.out.println(string1 + "has selected value" + field.getText());
			   }
			   if(string2=="selectByValue") 
				   
			   {
				   Select newselect=new Select(field);
			   			    newselect.selectByValue(string3);
			
			   }
			   
		  
		   }
		
public void verifyelement_visible_and_enable(WebElement elementname) {
	
	boolean enable= elementname.isEnabled();
	boolean visible=elementname.isDisplayed();
	if (enable && visible==true) {
		System.out.println("Element is present"+ elementname);
		}
		{
		  System.out.println("Element is not present"+ elementname);
	}
	
	
}
		
	
		
	public void Clickbutton(By string2)
	{
		
		WebElement field=driver.findElement(string2);
	
		field.click();
		
	}
	public void retrieveandcompare(By string1,By string2,By string3,By string4,By string5,By string6,By string7,By string8,By string9,By string10) {
		 {
		
		String incomefield_enteredtext=getvalue(string1,"incomefield_enteredtext");
		String otherincome_enteredtext=getvalue(string2,"otherincome_enteredtext");
		String living_expense_enteredtext=getvalue(string3,"living_expense_enteredtext");
		String loan_repayment_enteredtext=getvalue(string4,"loan_repayment_enteredtext");
		String otherloanreapayment_enteredtext=getvalue(string5,"otherloanreapayment_enteredtext");
		String othercommitment_enteredtext=getvalue(string6,"othercommitment_enteredtext");
		String creditcardlimit_enteredtext=getvalue(string7,"creditcardlimit_enteredtext");
		String Dependent_selected=getvalue(string8,"dependent_value");
		System.out.println("to check step execution" + incomefield_enteredtext);
		try {
		Assert.assertEquals("80,000",incomefield_enteredtext);
		Assert.assertEquals("10,000",otherincome_enteredtext);
		Assert.assertEquals("500",living_expense_enteredtext);
		Assert.assertEquals("0",loan_repayment_enteredtext);
		Assert.assertEquals("100",otherloanreapayment_enteredtext);
		Assert.assertEquals("0",othercommitment_enteredtext);
		Assert.assertEquals("10,000",creditcardlimit_enteredtext);
		Assert.assertEquals("0",Dependent_selected);
					
			String expected_borrowing_estimate_amount = "479000";
			System.out.println("to check step execution" + expected_borrowing_estimate_amount);
		String actual_borrowing_estimate_amount=getvalue(string10,"expected_borrowing_estimate_amount");
		
		//boolean comapareborrowing_amount=compare(actual_borrowing_estimate_amount,expected_borrowing_estimate_amount);
		//System.out.println("to check step execution" + comapareborrowing_amount);
		if (actual_borrowing_estimate_amount==expected_borrowing_estimate_amount) {
		System.out.println("estimate amount is correct");
		}
		else {System.out.println("estimate amount is not correct");}
				    
		} 
		catch (Exception e) {
		    String expectedMessage = "this is the message I expect to get";
		    Assert.assertEquals( "Exception message must be correct", expectedMessage, e.getMessage() );
		}} 
		}
		
		

public void navigateURL(String urllink) {
		
	driver.navigate().to(urllink);
	try{
		  Assert.assertEquals(urllink, driver.getCurrentUrl());
		  System.out.println("Navigated to correct webpage"+ driver.getCurrentUrl());
		  System.out.println("user is on homepage of ANZ Calculator"+ driver.getCurrentUrl());
		}
		catch(Throwable pageNavigationError){
		  System.out.println("Didn't navigate to correct webpage");
		}
	driver.manage().window().maximize();

		
		
		
	}
public void formreset(By string1,By string2,By string3,By string4,By string5,By string6,By string7,By string8,By string9,By string10) {
	

	
	String incomefield_enteredtext=getvalue(string1,"incomefield_enteredtext");
	String otherincome_enteredtext=getvalue(string2,"otherincome_enteredtext");
	String living_expense_enteredtext=getvalue(string3,"living_expense_enteredtext");
	String loan_repayment_enteredtext=getvalue(string4,"loan_repayment_enteredtext");
	String otherloanreapayment_enteredtext=getvalue(string5,"otherloanreapayment_enteredtext");
	String othercommitment_enteredtext=getvalue(string6,"othercommitment_enteredtext");
	String creditcardlimit_enteredtext=getvalue(string7,"creditcardlimit_enteredtext");
	String Dependent_selected=getvalue(string8,"dependent_value");
	//System.out.println("to check step execution" + incomefield_enteredtext);
	try {
	Assert.assertEquals("0",incomefield_enteredtext);
	Assert.assertEquals("0",otherincome_enteredtext);
	Assert.assertEquals("0",living_expense_enteredtext);
	Assert.assertEquals("0",loan_repayment_enteredtext);
	Assert.assertEquals("0",otherloanreapayment_enteredtext);
	Assert.assertEquals("0",othercommitment_enteredtext);
	Assert.assertEquals("0",creditcardlimit_enteredtext);
	//Assert.assertEquals("2",Dependent_selected);
				
		
		System.out.println("form reset done" );
	
			    
	} 
	catch (Exception e) {
	    String expectedMessage = "this is the message I expect to get";
	    Assert.assertEquals( "Exception message must be correct", expectedMessage, e.getMessage() );
	}  
	}




	public void calculatorpage(String calPagefieldname,String inputvalue) {
		
	
		
		switch (calPagefieldname) {
		case "Incomebeforetax":
			try {
			getIncomebeforetax(inputvalue);
				break;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		case "Applicationtype":
			try {
			getApplicationtype(inputvalue);
			break;
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "NoOfdependents":
			try {
			getNoOfdependents(inputvalue);
			break;
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "PropertyType":
			try {
			getPropertyType(inputvalue);
			break;	
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "Otherincome":
			try {
			getOtherincome(inputvalue);
			break;
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "Livingexpense":
			try {
			getlivingexpense(inputvalue);
			break;
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "loanrepayment":
			try {
			getloanrepayment(inputvalue);
			break;
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "Otherloanreapayment":
			try {
			getotherloanreapayment(inputvalue);
			break;
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "OtherCommitment":
			try {
			getotherCommitment(inputvalue);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		case "CreditCardLimit":
			try {
			getotherCreditCardLimit(inputvalue);
			break;	
			} catch (Exception e) {
				e.printStackTrace();
			}

		default:
			System.out.println("default");
			
		}
	
}
	
				
		
private void getIncomebeforetax(String inputvalue) {
	setvalue(incomefieldpath,inputvalue);
	
}

private void getotherCreditCardLimit(String inputvalue) {
	setvalue(creditCardLimit,inputvalue);
		
	}

private void getotherCommitment(String inputvalue) {
	setvalue(otherCommitment,inputvalue);
		
	}

private void getotherloanreapayment(String inputvalue) {
	setvalue(otherloanreapayment,inputvalue);
		
	}

private void getloanrepayment(String inputvalue) {
	setvalue(loanrepayment,inputvalue);
	}

private void getOtherincome(String inputvalue) {
	setvalue(otherincome,inputvalue);
	
}

private void getlivingexpense(String inputvalue) {
	setvalue(livingexpense,inputvalue);
		
	}

private void getPropertyType(String inputvalue) {
	Clickbutton(propertyType);
		
	}

private void getNoOfdependents(String inputvalue) {
	selectvalue(dependents,"selectByVisibleText",inputvalue);
		
	}

private void getApplicationtype(String inputvalue) {
	Clickbutton(applicationtype);
}


}
	
	  enum Browsers {
		
		CHROME,
		FIREFOX,
		IE

	}
	


	 
	



	







	
	
	

	

