##Cucumber-BDD-Automation-Framework

Behavior Driven Development Cucumber - Selenium-Cucumber-Maven framework with Page Object Model.
JAVA based

##The source structure of Maven Project:

	#src/main/test/java/Features: feature file (all test scenarios)
	#src/main/test/java/Pageobjectrepo:  calculator  page elements and methods (POM)
	#src/main/test/java/Stepdefinitions: glued code with feature file
	#src/main/Resources: Browsers file

##Prerequisite to setup 

	#Install java and set up environment variable 
          1.JAVA_HOME
          2.java Path
	# install maven and set up environment variable 
   		1.M2_HOME
   		2.MAVEN_HOME
   		3.Path
     #POM XML- Configuration file with all dependencies and MAVEN build   
   

 ##How to Run the Project 
   		1. Clone the project repository from github. 
   		2. import the project in eclipse as maven project.
   		3. Open cmd and traverse to the root folder of your maven project.
   		4  Run mvn clean.
   		5. Run mvn Test.
 
 
 ##To verify test  reports
   # Maven Test  will generate the  generate surefile-reports 
     Anzcalculator\target\surefire-reports
   # HTML reports  will be generated under /anzcalculator/target/HtmlReports 
   
  
  ##Note-  Tests are written to execute in windows with chrome browser.can be enhanced to execute in         different browser and different operating system by enhancing testbase class 
